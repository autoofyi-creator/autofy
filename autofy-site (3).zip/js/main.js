(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* ───────── Config (edit here) ───────── */
  const CFG = {
    notifyEmail: 'autoofyi@gmail.com',
    // Availability in India Standard Time (IST, UTC+5:30), Mon–Fri
    istStartMin: 17 * 60,        // first slot 5:00 PM IST  (~6:30 AM US Eastern)
    istEndMin: 23 * 60,          // last slot  11:00 PM IST (~12:30 PM US Eastern)
    slotMin: 30,
    daysAhead: 21,
    leadHours: 12,               // earliest bookable = now + 12h
    weekdaysIST: [1, 2, 3, 4, 5],
  };
  const IST = 330;

  /* ───────── Nav ───────── */
  const nav = $('#nav'), burger = $('#burger'), links = $('#navLinks');
  const onScroll = () => nav.classList.toggle('is-stuck', scrollY > 12);
  onScroll(); addEventListener('scroll', onScroll, { passive: true });
  burger.addEventListener('click', () => {
    const o = links.classList.toggle('open');
    burger.setAttribute('aria-expanded', o);
  });
  links.addEventListener('click', e => { if (e.target.closest('a')) { links.classList.remove('open'); burger.setAttribute('aria-expanded', false); } });

  /* ───────── Reveal on scroll ───────── */
  const revealEls = $$('.reveal, .display');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach(el => io.observe(el));
  } else revealEls.forEach(el => el.classList.add('in'));
  requestAnimationFrame(() => $('.display')?.classList.add('in'));

  /* ───────── Phone screen cycling ───────── */
  $$('[data-cycle]').forEach(box => {
    const imgs = $$('img', box); let i = 0;
    imgs[0].classList.add('on');
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const every = +box.dataset.interval || 2800;
    setInterval(() => {
      imgs[i].classList.remove('on'); i = (i + 1) % imgs.length; imgs[i].classList.add('on');
    }, every);
  });

  /* ───────── Copy buttons ───────── */
  $$('.copy').forEach(b => b.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(b.dataset.copy); }
    catch { const t = document.createElement('textarea'); t.value = b.dataset.copy; document.body.append(t); t.select(); document.execCommand('copy'); t.remove(); }
    const old = b.textContent; b.textContent = 'Copied'; b.classList.add('done');
    setTimeout(() => { b.textContent = old; b.classList.remove('done'); }, 1400);
  }));

  /* ───────── WhatsApp request modal ───────── */
  const WA = '919366065001';
  const modal = $('#reqModal'), reqForm = $('#reqForm'), reqMsg = $('#reqMsg');
  let reqProduct = 'Billing software';
  const okPhone = p => p.replace(/\D/g, '').length >= 7 && /^\+?[0-9\s\-().]{7,30}$/.test(p);
  function openReq(product) {
    reqProduct = product; $('#reqKind').textContent = product + ' demo'; reqMsg.textContent = '';
    modal.showModal ? modal.showModal() : modal.setAttribute('open', '');
  }
  $('#reqClose').addEventListener('click', () => modal.close());
  modal.addEventListener('click', e => { if (e.target === modal) modal.close(); });
  reqForm.addEventListener('submit', async e => {
    e.preventDefault(); reqMsg.textContent = '';
    const fd = new FormData(reqForm), name = (fd.get('name') || '').trim(), phone = (fd.get('phone') || '').trim();
    if (!name) return (reqMsg.textContent = 'Please enter your name.');
    if (!okPhone(phone)) return (reqMsg.textContent = 'Please enter a valid number with country code, e.g. +1 555 123 4567.');
    const waText = `Hi Autofy, I'd like the ${reqProduct} demo. My name is ${name} and my number is ${phone}.`;
    const waUrl = `https://wa.me/${WA}?text=${encodeURIComponent(waText)}`;
    const w = window.open('', '_blank');           // open synchronously so popup blockers allow it
    const b = $('#reqBtn'); b.disabled = true;
    await sendLead({ name, phone, product: reqProduct, website: fd.get('website') || '' });
    b.disabled = false; modal.close(); reqForm.reset();
    if (w) w.location.href = waUrl; else location.href = waUrl;
  });
  async function sendLead(d) {
    try { const r = await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) }); if (r.ok || r.status === 400) return; } catch {}
    try {
      await fetch('https://formsubmit.co/ajax/' + CFG.notifyEmail, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ _subject: `${d.product} request: ${d.name} (${d.phone})`, _captcha: 'false', _template: 'table', Name: d.name, Phone: d.phone, Product: d.product }) });
    } catch {}
  }

  /* ───────── APK availability: if file isn't uploaded yet, show a graceful state ───────── */
  $$('[data-apk]').forEach(a => {
    fetch(a.getAttribute('href'), { method: 'HEAD' }).then(r => {
      if (!r.ok) throw 0;
    }).catch(() => {
      a.removeAttribute('download'); a.setAttribute('href', '#');
      a.innerHTML = 'Get it on WhatsApp <span class="arr">→</span>';
      a.addEventListener('click', e => { e.preventDefault(); openReq(a.closest('.demo__body').querySelector('.h3').textContent); });
    });
  });

  const sc = $('#stickyCta'), bk = $('#book');
  const upd = () => { const r = bk.getBoundingClientRect(); sc.classList.toggle('show', scrollY > 500 && !(r.top < innerHeight && r.bottom > 0)); };
  addEventListener('scroll', upd, { passive: true }); upd();

  $('#yr').textContent = new Date().getFullYear();

  /* ───────── Calendly embed (lazy) ───────── */
  const frame = $('#calFrame');
  let calLoaded = false;
  function loadCal() {
    if (calLoaded) return; calLoaded = true;
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'https://assets.calendly.com/assets/external/widget.css'; document.head.append(css);
    const sc2 = document.createElement('script'); sc2.src = 'https://assets.calendly.com/assets/external/widget.js'; sc2.async = true;
    sc2.onerror = () => frame.classList.add('failed');
    document.body.append(sc2);
    setTimeout(() => { if (!$('iframe', frame)) frame.classList.add('failed'); }, 8000);
  }
  if ('IntersectionObserver' in window) {
    new IntersectionObserver((es, o) => { if (es[0].isIntersecting) { loadCal(); o.disconnect(); } }, { rootMargin: '600px 0px' }).observe(frame);
  } else loadCal();
})();
