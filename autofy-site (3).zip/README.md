# Autofy website: deploy on Vercel

Static site + one serverless function (`/api/book`) that emails you when someone books a meeting.

## Deploy
1. Upload this folder to a GitHub repo and import it at vercel.com/new (Framework: **Other**, no build command), or run `vercel --prod` in this folder.
2. **Booking** runs on Calendly (https://calendly.com/autoofy/30min): every "Book a meeting" button opens it, and the calendar is embedded in the Book section. Calendly emails you each booking and handles availability, time zones, reminders and Google Meet/Zoom links (configure these in your Calendly account).
3. **Billing-demo requests (WhatsApp form)** can also email you: add `RESEND_API_KEY` in Vercel env vars (optional `TO_EMAIL`, `FROM_EMAIL`). Without it, FormSubmit.co is used: submit one test, then click the activation link they email to autoofyi@gmail.com.

## Add the billing app
Put the billing APK at `downloads/autofy-billing-demo.apk`. Until it exists, the button opens a small form (name + phone) and sends the visitor to WhatsApp (+91 93660 65001) while emailing you their number. Demo login is already on the page.

## Edit
- Booking hours: in your Calendly settings.
- Colours (Apple-style palette)/fonts: `:root` in `css/styles.css`.
- After you have a domain: add `<link rel="canonical">`, make `og:image` absolute, and add a sitemap.
